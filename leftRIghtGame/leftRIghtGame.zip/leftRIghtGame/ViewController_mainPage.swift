//
//  ViewController_mainPage.swift
//  leftRIghtGame
//
//  Created by Matthew Anning on 5/2/20.
//  Copyright © 2020 Matthew Anning. All rights reserved.
//

import UIKit

class ViewController_mainPage: UIViewController {

   
    @IBOutlet weak var label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //NameOfApp.transform = NameOfApp.transform.rotated(by: CGFloat(Double.pi / 4 ))
        // Do any additional setup after loading the view.
    }
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
